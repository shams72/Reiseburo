/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGroupBox *groupBox;
    QTextEdit *KundenId;
    QLabel *label;
    QLabel *label_2;
    QTextEdit *Kundenname;
    QTextEdit *ReiseID;
    QLabel *label_4;
    QPushButton *pushButton_4;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QLabel *label_5;
    QTextEdit *ReiseID_2;
    QGroupBox *groupBox_3;
    QLabel *label_6;
    QLabel *label_7;
    QTextEdit *BuchungID;
    QTextEdit *Preis;
    QLabel *label_8;
    QLabel *label_9;
    QTabWidget *Tabs;
    QWidget *Hotel;
    QTextEdit *Hotelname;
    QLabel *label_10;
    QTextEdit *Stadt;
    QLabel *label_11;
    QTextEdit *Zimmer;
    QLabel *label_12;
    QPushButton *pushButton_3;
    QLabel *label_20;
    QLabel *label_21;
    QTextEdit *Zimmer_2;
    QTextEdit *Zimmer_3;
    QWidget *Flight;
    QTextEdit *FromDest;
    QLabel *label_13;
    QTextEdit *ToDest;
    QLabel *label_14;
    QTextEdit *Airline;
    QLabel *label_15;
    QPushButton *pushButton;
    QLabel *label_29;
    QLabel *label_27;
    QLabel *label_26;
    QTextEdit *Vehicleclass_9;
    QTextEdit *Vehicleclass_7;
    QLabel *label_28;
    QTextEdit *Vehicleclass_6;
    QTextEdit *Vehicleclass_8;
    QWidget *RentalCar;
    QTextEdit *Pickup;
    QLabel *label_16;
    QTextEdit *Return;
    QLabel *label_17;
    QTextEdit *Company;
    QLabel *label_18;
    QLabel *label_19;
    QTextEdit *Vehicleclass;
    QPushButton *pushButton_2;
    QTextEdit *Vehicleclass_3;
    QLabel *label_22;
    QTextEdit *Vehicleclass_2;
    QLabel *label_25;
    QLabel *label_23;
    QLabel *label_24;
    QTextEdit *Vehicleclass_4;
    QTextEdit *Vehicleclass_5;
    QDateEdit *StartDate;
    QDateEdit *Enddate;
    QPushButton *pushButton_5;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1572, 989);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName("groupBox");
        groupBox->setGeometry(QRect(30, 0, 431, 421));
        KundenId = new QTextEdit(groupBox);
        KundenId->setObjectName("KundenId");
        KundenId->setGeometry(QRect(110, 100, 161, 31));
        label = new QLabel(groupBox);
        label->setObjectName("label");
        label->setGeometry(QRect(20, 100, 70, 31));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(20, 50, 71, 31));
        Kundenname = new QTextEdit(groupBox);
        Kundenname->setObjectName("Kundenname");
        Kundenname->setGeometry(QRect(110, 50, 161, 31));
        ReiseID = new QTextEdit(groupBox);
        ReiseID->setObjectName("ReiseID");
        ReiseID->setGeometry(QRect(110, 150, 161, 31));
        label_4 = new QLabel(groupBox);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(10, 150, 70, 31));
        pushButton_4 = new QPushButton(groupBox);
        pushButton_4->setObjectName("pushButton_4");
        pushButton_4->setGeometry(QRect(120, 350, 121, 51));
        radioButton = new QRadioButton(groupBox);
        radioButton->setObjectName("radioButton");
        radioButton->setGeometry(QRect(120, 210, 107, 24));
        radioButton_2 = new QRadioButton(groupBox);
        radioButton_2->setObjectName("radioButton_2");
        radioButton_2->setGeometry(QRect(120, 250, 107, 24));
        label_5 = new QLabel(groupBox);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(10, 290, 111, 31));
        ReiseID_2 = new QTextEdit(groupBox);
        ReiseID_2->setObjectName("ReiseID_2");
        ReiseID_2->setGeometry(QRect(110, 290, 161, 31));
        groupBox_3 = new QGroupBox(centralwidget);
        groupBox_3->setObjectName("groupBox_3");
        groupBox_3->setGeometry(QRect(740, 20, 481, 911));
        label_6 = new QLabel(groupBox_3);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(20, 20, 91, 31));
        label_7 = new QLabel(groupBox_3);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(20, 70, 71, 31));
        BuchungID = new QTextEdit(groupBox_3);
        BuchungID->setObjectName("BuchungID");
        BuchungID->setGeometry(QRect(170, 20, 161, 31));
        Preis = new QTextEdit(groupBox_3);
        Preis->setObjectName("Preis");
        Preis->setGeometry(QRect(170, 160, 161, 31));
        label_8 = new QLabel(groupBox_3);
        label_8->setObjectName("label_8");
        label_8->setGeometry(QRect(20, 150, 71, 31));
        label_9 = new QLabel(groupBox_3);
        label_9->setObjectName("label_9");
        label_9->setGeometry(QRect(20, 110, 71, 31));
        Tabs = new QTabWidget(groupBox_3);
        Tabs->setObjectName("Tabs");
        Tabs->setGeometry(QRect(0, 230, 461, 521));
        Hotel = new QWidget();
        Hotel->setObjectName("Hotel");
        Hotelname = new QTextEdit(Hotel);
        Hotelname->setObjectName("Hotelname");
        Hotelname->setGeometry(QRect(150, 20, 161, 31));
        label_10 = new QLabel(Hotel);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(20, 60, 71, 31));
        Stadt = new QTextEdit(Hotel);
        Stadt->setObjectName("Stadt");
        Stadt->setGeometry(QRect(150, 60, 161, 31));
        label_11 = new QLabel(Hotel);
        label_11->setObjectName("label_11");
        label_11->setGeometry(QRect(20, 20, 111, 31));
        Zimmer = new QTextEdit(Hotel);
        Zimmer->setObjectName("Zimmer");
        Zimmer->setGeometry(QRect(150, 110, 161, 31));
        label_12 = new QLabel(Hotel);
        label_12->setObjectName("label_12");
        label_12->setGeometry(QRect(20, 110, 91, 31));
        pushButton_3 = new QPushButton(Hotel);
        pushButton_3->setObjectName("pushButton_3");
        pushButton_3->setGeometry(QRect(140, 280, 121, 51));
        label_20 = new QLabel(Hotel);
        label_20->setObjectName("label_20");
        label_20->setGeometry(QRect(20, 160, 121, 31));
        label_21 = new QLabel(Hotel);
        label_21->setObjectName("label_21");
        label_21->setGeometry(QRect(20, 210, 121, 31));
        Zimmer_2 = new QTextEdit(Hotel);
        Zimmer_2->setObjectName("Zimmer_2");
        Zimmer_2->setGeometry(QRect(150, 210, 161, 31));
        Zimmer_3 = new QTextEdit(Hotel);
        Zimmer_3->setObjectName("Zimmer_3");
        Zimmer_3->setGeometry(QRect(150, 160, 161, 31));
        Tabs->addTab(Hotel, QString());
        Flight = new QWidget();
        Flight->setObjectName("Flight");
        FromDest = new QTextEdit(Flight);
        FromDest->setObjectName("FromDest");
        FromDest->setGeometry(QRect(180, 20, 161, 31));
        label_13 = new QLabel(Flight);
        label_13->setObjectName("label_13");
        label_13->setGeometry(QRect(30, 60, 71, 31));
        ToDest = new QTextEdit(Flight);
        ToDest->setObjectName("ToDest");
        ToDest->setGeometry(QRect(180, 60, 161, 31));
        label_14 = new QLabel(Flight);
        label_14->setObjectName("label_14");
        label_14->setGeometry(QRect(30, 20, 71, 31));
        Airline = new QTextEdit(Flight);
        Airline->setObjectName("Airline");
        Airline->setGeometry(QRect(180, 110, 161, 31));
        label_15 = new QLabel(Flight);
        label_15->setObjectName("label_15");
        label_15->setGeometry(QRect(30, 100, 71, 31));
        pushButton = new QPushButton(Flight);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(150, 380, 121, 51));
        label_29 = new QLabel(Flight);
        label_29->setObjectName("label_29");
        label_29->setGeometry(QRect(30, 160, 121, 31));
        label_27 = new QLabel(Flight);
        label_27->setObjectName("label_27");
        label_27->setGeometry(QRect(30, 260, 121, 31));
        label_26 = new QLabel(Flight);
        label_26->setObjectName("label_26");
        label_26->setGeometry(QRect(30, 310, 131, 31));
        Vehicleclass_9 = new QTextEdit(Flight);
        Vehicleclass_9->setObjectName("Vehicleclass_9");
        Vehicleclass_9->setGeometry(QRect(180, 260, 161, 31));
        Vehicleclass_7 = new QTextEdit(Flight);
        Vehicleclass_7->setObjectName("Vehicleclass_7");
        Vehicleclass_7->setGeometry(QRect(180, 310, 161, 31));
        label_28 = new QLabel(Flight);
        label_28->setObjectName("label_28");
        label_28->setGeometry(QRect(30, 210, 131, 31));
        Vehicleclass_6 = new QTextEdit(Flight);
        Vehicleclass_6->setObjectName("Vehicleclass_6");
        Vehicleclass_6->setGeometry(QRect(180, 160, 161, 31));
        Vehicleclass_8 = new QTextEdit(Flight);
        Vehicleclass_8->setObjectName("Vehicleclass_8");
        Vehicleclass_8->setGeometry(QRect(180, 210, 161, 31));
        Tabs->addTab(Flight, QString());
        RentalCar = new QWidget();
        RentalCar->setObjectName("RentalCar");
        Pickup = new QTextEdit(RentalCar);
        Pickup->setObjectName("Pickup");
        Pickup->setGeometry(QRect(180, 40, 161, 31));
        label_16 = new QLabel(RentalCar);
        label_16->setObjectName("label_16");
        label_16->setGeometry(QRect(40, 80, 71, 31));
        Return = new QTextEdit(RentalCar);
        Return->setObjectName("Return");
        Return->setGeometry(QRect(180, 80, 161, 31));
        label_17 = new QLabel(RentalCar);
        label_17->setObjectName("label_17");
        label_17->setGeometry(QRect(40, 40, 71, 31));
        Company = new QTextEdit(RentalCar);
        Company->setObjectName("Company");
        Company->setGeometry(QRect(180, 130, 161, 31));
        label_18 = new QLabel(RentalCar);
        label_18->setObjectName("label_18");
        label_18->setGeometry(QRect(40, 130, 71, 31));
        label_19 = new QLabel(RentalCar);
        label_19->setObjectName("label_19");
        label_19->setGeometry(QRect(40, 180, 111, 31));
        Vehicleclass = new QTextEdit(RentalCar);
        Vehicleclass->setObjectName("Vehicleclass");
        Vehicleclass->setGeometry(QRect(180, 180, 161, 31));
        pushButton_2 = new QPushButton(RentalCar);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(150, 430, 121, 51));
        Vehicleclass_3 = new QTextEdit(RentalCar);
        Vehicleclass_3->setObjectName("Vehicleclass_3");
        Vehicleclass_3->setGeometry(QRect(180, 230, 161, 31));
        label_22 = new QLabel(RentalCar);
        label_22->setObjectName("label_22");
        label_22->setGeometry(QRect(40, 370, 131, 31));
        Vehicleclass_2 = new QTextEdit(RentalCar);
        Vehicleclass_2->setObjectName("Vehicleclass_2");
        Vehicleclass_2->setGeometry(QRect(180, 370, 161, 31));
        label_25 = new QLabel(RentalCar);
        label_25->setObjectName("label_25");
        label_25->setGeometry(QRect(40, 330, 121, 31));
        label_23 = new QLabel(RentalCar);
        label_23->setObjectName("label_23");
        label_23->setGeometry(QRect(40, 280, 131, 31));
        label_24 = new QLabel(RentalCar);
        label_24->setObjectName("label_24");
        label_24->setGeometry(QRect(40, 230, 121, 31));
        Vehicleclass_4 = new QTextEdit(RentalCar);
        Vehicleclass_4->setObjectName("Vehicleclass_4");
        Vehicleclass_4->setGeometry(QRect(180, 280, 161, 31));
        Vehicleclass_5 = new QTextEdit(RentalCar);
        Vehicleclass_5->setObjectName("Vehicleclass_5");
        Vehicleclass_5->setGeometry(QRect(180, 330, 161, 31));
        Tabs->addTab(RentalCar, QString());
        StartDate = new QDateEdit(groupBox_3);
        StartDate->setObjectName("StartDate");
        StartDate->setGeometry(QRect(170, 70, 161, 31));
        Enddate = new QDateEdit(groupBox_3);
        Enddate->setObjectName("Enddate");
        Enddate->setGeometry(QRect(170, 110, 161, 31));
        pushButton_5 = new QPushButton(centralwidget);
        pushButton_5->setObjectName("pushButton_5");
        pushButton_5->setGeometry(QRect(140, 490, 121, 51));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1572, 26));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        Tabs->setCurrentIndex(2);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        groupBox->setTitle(QCoreApplication::translate("MainWindow", "Kunden", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Name", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "Reise ID", nullptr));
        pushButton_4->setText(QCoreApplication::translate("MainWindow", "OK", nullptr));
        radioButton->setText(QCoreApplication::translate("MainWindow", "Add Booking", nullptr));
        radioButton_2->setText(QCoreApplication::translate("MainWindow", "Add TravelID", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "New Reise ID", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("MainWindow", "Buchungdetails", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "BuchungId", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "Start", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "Preis", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "Ende", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "Stadt", nullptr));
        label_11->setText(QCoreApplication::translate("MainWindow", "HotelNmae", nullptr));
        label_12->setText(QCoreApplication::translate("MainWindow", "Zimmertyp", nullptr));
        pushButton_3->setText(QCoreApplication::translate("MainWindow", "OK", nullptr));
        label_20->setText(QCoreApplication::translate("MainWindow", "Hotellongitude", nullptr));
        label_21->setText(QCoreApplication::translate("MainWindow", "HotelLatitude", nullptr));
        Tabs->setTabText(Tabs->indexOf(Hotel), QCoreApplication::translate("MainWindow", "Hotel", nullptr));
        label_13->setText(QCoreApplication::translate("MainWindow", "To", nullptr));
        label_14->setText(QCoreApplication::translate("MainWindow", "From", nullptr));
        label_15->setText(QCoreApplication::translate("MainWindow", "Airline", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "OK", nullptr));
        label_29->setText(QCoreApplication::translate("MainWindow", "FromLatitude", nullptr));
        label_27->setText(QCoreApplication::translate("MainWindow", "ToLatitude", nullptr));
        label_26->setText(QCoreApplication::translate("MainWindow", "ToLongitude", nullptr));
        label_28->setText(QCoreApplication::translate("MainWindow", "Fromlongoitude", nullptr));
        Tabs->setTabText(Tabs->indexOf(Flight), QCoreApplication::translate("MainWindow", "Flight", nullptr));
        label_16->setText(QCoreApplication::translate("MainWindow", "Return", nullptr));
        label_17->setText(QCoreApplication::translate("MainWindow", "Pickup", nullptr));
        label_18->setText(QCoreApplication::translate("MainWindow", "Company", nullptr));
        label_19->setText(QCoreApplication::translate("MainWindow", "Vehicleclass", nullptr));
        pushButton_2->setText(QCoreApplication::translate("MainWindow", "OK", nullptr));
        label_22->setText(QCoreApplication::translate("MainWindow", "ReturnLongitude", nullptr));
        label_25->setText(QCoreApplication::translate("MainWindow", "ReturnLatitude", nullptr));
        label_23->setText(QCoreApplication::translate("MainWindow", "Pickuplongoitude", nullptr));
        label_24->setText(QCoreApplication::translate("MainWindow", "PickupLatitude", nullptr));
        Tabs->setTabText(Tabs->indexOf(RentalCar), QCoreApplication::translate("MainWindow", "RentalCar", nullptr));
        pushButton_5->setText(QCoreApplication::translate("MainWindow", "Done", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
