
#include "sortfunktor.h"


