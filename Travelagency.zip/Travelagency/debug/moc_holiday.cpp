/****************************************************************************
** Meta object code from reading C++ file 'holiday.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../holiday.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'holiday.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSholidayENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSholidayENDCLASS = QtMocHelpers::stringData(
    "holiday",
    "on_actionInformation_Anzieigen_triggered",
    "",
    "readFile",
    "on_actionAnzeigen_nach_ID_triggered",
    "on_ReisenBox_itemClicked",
    "QTableWidgetItem*",
    "item",
    "on_BuchungenBox_itemDoubleClicked",
    "on_pushButton_clicked",
    "on_pushButton_2_clicked",
    "on_actionShow_Airport_triggered",
    "on_pushButton_3_clicked",
    "on_actionAlle_Anzeigen_triggered",
    "on_Createfile_clicked",
    "on_actionhello_triggered",
    "on_pushButton_4_clicked",
    "on_pushButton_5_clicked",
    "on_pushButton_6_clicked"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSholidayENDCLASS_t {
    uint offsetsAndSizes[38];
    char stringdata0[8];
    char stringdata1[41];
    char stringdata2[1];
    char stringdata3[9];
    char stringdata4[36];
    char stringdata5[25];
    char stringdata6[18];
    char stringdata7[5];
    char stringdata8[34];
    char stringdata9[22];
    char stringdata10[24];
    char stringdata11[32];
    char stringdata12[24];
    char stringdata13[33];
    char stringdata14[22];
    char stringdata15[25];
    char stringdata16[24];
    char stringdata17[24];
    char stringdata18[24];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSholidayENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSholidayENDCLASS_t qt_meta_stringdata_CLASSholidayENDCLASS = {
    {
        QT_MOC_LITERAL(0, 7),  // "holiday"
        QT_MOC_LITERAL(8, 40),  // "on_actionInformation_Anzieige..."
        QT_MOC_LITERAL(49, 0),  // ""
        QT_MOC_LITERAL(50, 8),  // "readFile"
        QT_MOC_LITERAL(59, 35),  // "on_actionAnzeigen_nach_ID_tri..."
        QT_MOC_LITERAL(95, 24),  // "on_ReisenBox_itemClicked"
        QT_MOC_LITERAL(120, 17),  // "QTableWidgetItem*"
        QT_MOC_LITERAL(138, 4),  // "item"
        QT_MOC_LITERAL(143, 33),  // "on_BuchungenBox_itemDoubleCli..."
        QT_MOC_LITERAL(177, 21),  // "on_pushButton_clicked"
        QT_MOC_LITERAL(199, 23),  // "on_pushButton_2_clicked"
        QT_MOC_LITERAL(223, 31),  // "on_actionShow_Airport_triggered"
        QT_MOC_LITERAL(255, 23),  // "on_pushButton_3_clicked"
        QT_MOC_LITERAL(279, 32),  // "on_actionAlle_Anzeigen_triggered"
        QT_MOC_LITERAL(312, 21),  // "on_Createfile_clicked"
        QT_MOC_LITERAL(334, 24),  // "on_actionhello_triggered"
        QT_MOC_LITERAL(359, 23),  // "on_pushButton_4_clicked"
        QT_MOC_LITERAL(383, 23),  // "on_pushButton_5_clicked"
        QT_MOC_LITERAL(407, 23)   // "on_pushButton_6_clicked"
    },
    "holiday",
    "on_actionInformation_Anzieigen_triggered",
    "",
    "readFile",
    "on_actionAnzeigen_nach_ID_triggered",
    "on_ReisenBox_itemClicked",
    "QTableWidgetItem*",
    "item",
    "on_BuchungenBox_itemDoubleClicked",
    "on_pushButton_clicked",
    "on_pushButton_2_clicked",
    "on_actionShow_Airport_triggered",
    "on_pushButton_3_clicked",
    "on_actionAlle_Anzeigen_triggered",
    "on_Createfile_clicked",
    "on_actionhello_triggered",
    "on_pushButton_4_clicked",
    "on_pushButton_5_clicked",
    "on_pushButton_6_clicked"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSholidayENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  104,    2, 0x08,    1 /* Private */,
       3,    0,  105,    2, 0x08,    2 /* Private */,
       4,    0,  106,    2, 0x08,    3 /* Private */,
       5,    1,  107,    2, 0x08,    4 /* Private */,
       8,    1,  110,    2, 0x08,    6 /* Private */,
       9,    0,  113,    2, 0x08,    8 /* Private */,
      10,    0,  114,    2, 0x08,    9 /* Private */,
      11,    0,  115,    2, 0x08,   10 /* Private */,
      12,    0,  116,    2, 0x08,   11 /* Private */,
      13,    0,  117,    2, 0x08,   12 /* Private */,
      14,    0,  118,    2, 0x08,   13 /* Private */,
      15,    0,  119,    2, 0x08,   14 /* Private */,
      16,    0,  120,    2, 0x08,   15 /* Private */,
      17,    0,  121,    2, 0x08,   16 /* Private */,
      18,    0,  122,    2, 0x08,   17 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject holiday::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSholidayENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSholidayENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSholidayENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<holiday, std::true_type>,
        // method 'on_actionInformation_Anzieigen_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'readFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionAnzeigen_nach_ID_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_ReisenBox_itemClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTableWidgetItem *, std::false_type>,
        // method 'on_BuchungenBox_itemDoubleClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTableWidgetItem *, std::false_type>,
        // method 'on_pushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionShow_Airport_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_3_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionAlle_Anzeigen_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Createfile_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionhello_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_4_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_5_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_6_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void holiday::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<holiday *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_actionInformation_Anzieigen_triggered(); break;
        case 1: _t->readFile(); break;
        case 2: _t->on_actionAnzeigen_nach_ID_triggered(); break;
        case 3: _t->on_ReisenBox_itemClicked((*reinterpret_cast< std::add_pointer_t<QTableWidgetItem*>>(_a[1]))); break;
        case 4: _t->on_BuchungenBox_itemDoubleClicked((*reinterpret_cast< std::add_pointer_t<QTableWidgetItem*>>(_a[1]))); break;
        case 5: _t->on_pushButton_clicked(); break;
        case 6: _t->on_pushButton_2_clicked(); break;
        case 7: _t->on_actionShow_Airport_triggered(); break;
        case 8: _t->on_pushButton_3_clicked(); break;
        case 9: _t->on_actionAlle_Anzeigen_triggered(); break;
        case 10: _t->on_Createfile_clicked(); break;
        case 11: _t->on_actionhello_triggered(); break;
        case 12: _t->on_pushButton_4_clicked(); break;
        case 13: _t->on_pushButton_5_clicked(); break;
        case 14: _t->on_pushButton_6_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject *holiday::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *holiday::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSholidayENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int holiday::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 15;
    }
    return _id;
}
QT_WARNING_POP
